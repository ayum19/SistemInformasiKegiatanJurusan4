<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class Lpj extends Model {

	protected $primaryKey = 'id_lpj';
	
	public $timestamps = false;

	protected $table = 'lpj';


}
