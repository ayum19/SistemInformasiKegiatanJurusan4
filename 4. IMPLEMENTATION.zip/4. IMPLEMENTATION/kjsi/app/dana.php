<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class dana extends Model {

	protected $primaryKey = 'id_detaildana';
	
	public $timestamps = false;

	protected $table = 'detail_dana';

}
