<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class detail_people extends Model {

	//

}
