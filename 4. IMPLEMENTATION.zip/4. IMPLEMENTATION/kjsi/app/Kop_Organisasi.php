<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class Kop_Organisasi extends Model {

	protected $primaryKey = 'id_koporganisasi';
	
	public $timestamps = false;

	protected $table = 'kop_organisasi';

}
