@extends('layout') 

@section('konten')

@stop