@extends('layout') 

@section('konten')

<p>Selamat Datang</p>

@endsection